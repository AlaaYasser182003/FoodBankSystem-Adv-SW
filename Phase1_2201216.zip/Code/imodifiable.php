<?php

interface imodifiable {

    function add();
    function remove();
    function edit();
    function read();
    static function view_all();

}

?>